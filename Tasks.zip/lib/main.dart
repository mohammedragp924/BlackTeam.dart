import 'package:flutter/material.dart';
import 'package:helloworld/Screens/opening_screen.dart';
import 'Screens/login_screen.dart';
//import 'Screens/opening_screen.dart';

void main() {
  runApp(const OurQuizzApp());
}

class OurQuizzApp extends StatelessWidget {
  const OurQuizzApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        theme: ThemeData(
          primarySwatch: Colors.yellow,
        ),
        debugShowCheckedModeBanner: false,
        // ignore: prefer_const_constructors
        home: OpeningScreen());
  }
}
