import 'package:flutter/material.dart';
import 'package:helloworld/Screens/opening_screen.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: Stack(
          alignment: AlignmentDirectional.bottomCenter,
          children: [
            Container(
              height: MediaQuery.of(context).size.height,
              width: MediaQuery.of(context).size.width,
              decoration: const BoxDecoration(color: Colors.black),
              child: Align(
                  alignment: Alignment.topCenter,
                  child: Padding(
                    padding: EdgeInsets.only(
                        bottom: MediaQuery.of(context).size.height * 1 / 12,
                        left: 20,
                        right: 20,
                        top: MediaQuery.of(context).size.height * 1 / 12),
                    child: Image.asset(
                      "images/4.png",
                      height: MediaQuery.of(context).size.width * 1 / 2,
                      width: MediaQuery.of(context).size.width * 1 / 2,
                    ),
                  )),
            ),
            Container(
              // margin: EdgeInsets.symmetric(horizontal: 30, vertical: 40),
              padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 20),
              height: MediaQuery.of(context).size.height * 2 / 3,
              width: MediaQuery.of(context).size.width,
              decoration: const BoxDecoration(
                  color: Color(0xffb7a05b),
                  borderRadius:
                      BorderRadius.vertical(top: Radius.circular(50))),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const Text(
                    "Login",
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 40),
                  ),
                  const SizedBox(
                    height: 20,
                  ),

                  // Username text field
                  TextField(
                    decoration: InputDecoration(
                      prefixIcon: const Icon(Icons.person),
                      hintText: "Username",
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                    ),
                  ),

                  const SizedBox(
                    height: 18,
                  ),

                  // Password text field
                  TextField(
                    decoration: InputDecoration(
                      prefixIcon: const Icon(Icons.lock),
                      suffixIcon: const Icon(Icons.visibility_off),
                      hintText: "Password",
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 12,
                  ),
                  Row(
                    children: [
                      const Spacer(),
                      const Text("New to quizz app? "),

                      TextButton(
                          onPressed: () {},
                          child: const Text("Register",
                              style: TextStyle(
                                  color: Color(0xff000000),
                                  decoration: TextDecoration.underline)))

                      // GestureDetector(onTap: () {}, child: Text("Register"))
                    ],
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  SizedBox(
                      width: MediaQuery.of(context).size.width / 2 - 60,
                      child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                              elevation: 25,
                              shadowColor: Colors.black,
                              backgroundColor: const Color(0xfffcff00),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(30))),
                          onPressed: () {
                            print("We sign you in...");
                          },
                          child: const Text(
                            "Login",
                            style: TextStyle(color: Color(0xff000000)),
                          ))),
                  const SizedBox(
                    height: 10,
                  ),
                  //

                  const Icon(
                    Icons.fingerprint,
                    size: 80,
                    color: Color(0xff000000),
                  ),
                  const SizedBox(
                    height: 12,
                  ),
                  const Text(
                    "Use Touch ID",
                    style: TextStyle(color: Color(0xff000000)),
                  ),
                  const Spacer(),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Checkbox(
                            value: true,
                            onChanged: (value) {},
                          ),
                          const Text(
                            "Remember me",
                            style: TextStyle(
                                color: Color(0xff000000),
                                decoration: TextDecoration.underline),
                          ),
                        ],
                      ),
                      TextButton(
                          onPressed: () {},
                          child: const Text("Forget Password?",
                              style: TextStyle(
                                  color: Color(0xff000000),
                                  decoration: TextDecoration.underline))),
                      const Spacer(),
                      Container(
                        // width: double.infinity,
                        margin: const EdgeInsets.symmetric(
                            vertical: 1, horizontal: 1),
                        child: ElevatedButton(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        const OpeningScreen()),
                              );
                            },
                            child: const Text(
                              "back",
                              style: TextStyle(
                                  color: Color(0xff000000), fontSize: 16),
                            )),
                      ),
                    ],
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
