import 'package:flutter/material.dart';
import 'login_screen.dart';

class OpeningScreen extends StatelessWidget {
  const OpeningScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          decoration: const BoxDecoration(
              image: DecorationImage(
                  image: NetworkImage(
                      "https://w0.peakpx.com/wallpaper/219/456/HD-wallpaper-abstract-art-black-gold-thumbnail.jpg"),
                  fit: BoxFit.cover)),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              SizedBox(
                height: MediaQuery.of(context).size.height * 0.15,
              ),
              const Text("iTi Chat App",
                  style: TextStyle(
                    color: Colors.yellow,
                    fontSize: 30,
                  )),
              const SizedBox(
                height: 12,
              ),
              const Text("We Are Creative, enjoy our App",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 26,
                  )),
              const Spacer(),
              Container(
                width: double.infinity,
                margin:
                    const EdgeInsets.symmetric(vertical: 28, horizontal: 26),
                child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const LoginScreen()),
                      );
                    },
                    child: const Text(
                      "Start",
                      style: TextStyle(color: Color(0xff000000), fontSize: 16),
                    )),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
